'''from flask import Flask


app = Flask(__name__)

from flask.ext.sqlalchemy import SQLAlchemy
import os

print "**************",os.getcwd()
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.db'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:/Users/Vikas/Desktop/microblog/db.db'
db = SQLAlchemy(app)
from app import views'''




from flask import Flask
from flask.ext.sqlalchemy import SQLAlchemy
from flask.ext.login import LoginManager


#Create an Instance of Flask
app = Flask(__name__)
#Include config from config.py
app.config.from_object('config')
app.secret_key = 'some_secret'
#Create an instance of SQLAclhemy
db = SQLAlchemy(app)
from app import views, models
from app.models import User

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))