from flask import render_template,flash, redirect, url_for, Blueprint, request
from app import app, db
from app.models import User
from flask import Flask, session, request, flash, url_for, redirect, render_template, abort,g
from flask.ext.login import login_user, logout_user, current_user, login_required

@app.route('/index/')
@login_required
def index():
    if current_user.issuperuser == "True":
        return redirect(request.args.get('next') or url_for('admin'))
    else:
        return render_template('userdetails.html')

@app.route('/admin/')
@login_required
def admin():
    data = User.query.all()
    return render_template('alluserdetails.html', data=data)


@app.route('/deleteuser/',methods=('POST','GET'))
@login_required
def deleteuser():
    if request.method == 'POST':
        id = request.form['id']
        user = User.query.get(id)
        db.session.delete(user)
        db.session.commit()
        data = User.query.all()
        return render_template('alluserdetails.html', data=data, message="The User \"%s\" has been deleted successfully!!"%user.username)
    else:
        return redirect(url_for('admin'))


@app.route('/addnewuser/', methods=('POST','GET'))
def addnewuser():
    if request.method == "POST":
        print "ininininininin"

        checkUserName = User.query.filter_by(username=request.form['username']).first()
        checkEmail = User.query.filter_by(email=request.form['email']).first()
        print request.form['username'],request.form['email']

        if request.form['password'] != request.form['confirmpassword']:
            return render_template('addnewuser.html', error="Password and Confirm Password Doesnt not match!")

        if checkUserName != None:
            return render_template('addnewuser.html', error="User Name %s is already exist!!"%request.form['username'])


        if checkEmail != None:
            return render_template('addnewuser.html', error="Email id %s is already exist!!" %request.form['email'])

        else:
            issuperuser="False"
            user=User(request.form['username'], request.form['email'],request.form['mobile'],request.form['password'], issuperuser)
            db.session.add(user)
            db.session.commit()
            return render_template('addnewuser.html', success="User \"%s\" has been added successfully!."%(request.form['username']))
    else:
        return render_template('addnewuser.html')



@app.route('/edit/',methods=('POST','GET'))
@login_required
def edit():
    if request.method == 'POST':
        id = request.form['id']
        user = User.query.get(id)
        return render_template('edituser.html', user=user)
    else:
        return redirect(url_for('admin'))
		

@app.route('/updateuserdetails/',methods=('POST','GET'))
@login_required
def updateuserdetails():
    if request.method == 'POST':
        user = User.query.get(request.form['id'])
        checkUserName = User.query.filter_by(username=request.form['username']).first()
        checkEmail = User.query.filter_by(email=request.form['email']).first()

        if checkUserName != None:
            return render_template('edituser.html', user=user, error="User Name %s is already exist!!" %request.form['username'])

        if checkEmail != None:
            return render_template('edituser.html', user=user, error="Email id %s is already exist!!" %request.form['email'])

        else:
            # user = User.query.get(request.form['id'])
            user.username = request.form['username']
            user.email = request.form['email']
            user.mobile = request.form['mobile']
            db.session.commit()
            data = User.query.all()
            return render_template('alluserdetails.html', main="Data has been updated successfully!!", data=data, user=user)
    else:
        return render_template('edituser.html')

		
@app.route('/edituserdetails/',methods=('POST','GET'))
@login_required
def edituserdetails():
    if request.method == 'POST':
        checkUserName = User.query.filter_by(username=request.form['username']).first()
        checkEmail = User.query.filter_by(email=request.form['email']).first()

        if checkUserName != None:
            return render_template('edituserdetails.html', error="User Name %s is already exist!!"%request.form['username'])

        if checkEmail != None:
            return render_template('edituserdetails.html', error="Email id %s is already exist!!" %request.form['email'])

        else:
            user = User.query.get(request.form['id'])
            user.username = request.form['username']
            user.email = request.form['email']
            user.mobile = request.form['mobile']
            # user=User(request.form['username'], request.form['email'],request.form['mobile'],request.form['password'], issuperuser)
            # db.session.add(user)
            db.session.commit()
            return render_template('edituserdetails.html', main="Your data has been updated successfully!!")
    else:
        return render_template('edituserdetails.html')


@app.route('/')
@app.route('/login/', methods=('POST','GET'))
def login():
    if request.method == 'GET':
        return render_template('login.html')
    username = request.form['username']
    password = request.form['password']
    registered_user = User.query.filter_by(username=username,password=password).first()
    if registered_user is None:
        flash('Username or Password is invalid' , 'error')
        return redirect(url_for('login'))
    login_user(registered_user)
    return redirect(request.args.get('next') or url_for('index'))


@app.route('/logout/')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


@app.route('/registration/', methods=('POST','GET'))
def registration():
    if request.method == "POST":
        checkUserName = User.query.filter_by(username=request.form['username']).first()

        if request.form['password'] != request.form['repassword']:
            return render_template('registration.html', error="Password and Confirm Password Doesnt not match!")

        if checkUserName != None:
            return render_template('registration.html', error="User Name %s is already exist!!"%request.form['username'])

        checkEmail = User.query.filter_by(email=request.form['email']).first()
        if checkEmail != None:
            return render_template('registration.html', error="Email id %s is already exist!!" %request.form['email'])

        else:
            issuperuser="False"
            user=User(request.form['username'], request.form['email'],request.form['mobile'],request.form['password'], issuperuser)
            db.session.add(user)
            db.session.commit()
            return render_template('registration.html', main="Registration is successfully done!!")
    else:
        return render_template('registration.html')
