from app import db


class User(db.Model):  
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True)
    email = db.Column(db.String(120), unique=True)
    mobile = db.Column(db.INTEGER, unique=False)
    password = db.Column(db.LargeBinary(120), unique=False)
    issuperuser = db.Column(db.String(1), unique=False)


    def __init__(self, username, email, mobile, password, issuperuser):
        self.username = username
        self.email = email
        self.mobile = mobile
        self.password = password
        self.issuperuser = issuperuser

    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return False

    def get_id(self):
        return unicode(self.id)

    def __repr__(self):
        return '<User %r>' % self.usernames