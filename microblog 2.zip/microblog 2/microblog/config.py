# SQLALCHEMY_DATABASE_URI = 'sqlite:///db.db'

SQLALCHEMY_DATABASE_URI = 'sqlite:////Users/Vikas/Desktop/microblog/db.db'

WTF_CSRF_ENABLED = True
SECRET_KEY = 'you-will-never-guess'