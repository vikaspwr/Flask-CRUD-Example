from app import app
# app.debug=True
# app.run(host='1.2.3.4')
if __name__ == '__main__':
    app.run(debug=True)